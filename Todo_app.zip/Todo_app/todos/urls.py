from django.urls import path
from .views import add_todo, delete, home, update, supdate

urlpatterns = [
    path('home/', home, name = 'home'),
    path('add_todo/', add_todo, name='add_todo'),
    path('Update/<int:todo_id>', update, name ='show_update' ),
    path('update/<int:todo_id>',update, name = 'update'),
    path('supdate/<int:todo_id>', supdate, name = 'supdate'),
    path('delete/<int:todo_id>', delete, name ="delete" ),
]